## INSTALLATION

1. Extract zip file. ex. d:\shopping
2. Open Cli, go to the shopping folder. ex. cd d:\shopping
3. Type npm install
4. Type ionic serve to see.

## PAGES
-present (ask for gender)
-Login
-signup
reset (forgot password)
-home
-cart
-profil
-categories
-list(categories-list) for each category
-collections
-list-collections (for each collection)
-show (to view a product detail)
-checkout(1, 2, 3)

## PLUGINS
-photoviewer

## IMPORTANT
The project is configured on ios mode in module.ts
 
// imports: [IonicModule.forRoot( { rippleEffect: false, mode: 'ios' })]