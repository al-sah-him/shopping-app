import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout3',
  templateUrl: './checkout3.page.html',
  styleUrls: ['./checkout3.page.scss'],
})
export class Checkout3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
