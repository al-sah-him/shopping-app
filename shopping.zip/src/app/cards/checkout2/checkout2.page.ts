import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout2',
  templateUrl: './checkout2.page.html',
  styleUrls: ['./checkout2.page.scss'],
})
export class Checkout2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
