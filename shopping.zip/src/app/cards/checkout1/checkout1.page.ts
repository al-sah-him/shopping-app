import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout1',
  templateUrl: './checkout1.page.html',
  styleUrls: ['./checkout1.page.scss'],
})
export class Checkout1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
